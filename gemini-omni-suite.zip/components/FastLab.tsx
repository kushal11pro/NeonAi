import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Zap, FileText, CheckCheck } from 'lucide-react';

export const FastLab: React.FC = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [mode, setMode] = useState<'summarize' | 'grammar'>('summarize');
  const [loading, setLoading] = useState(false);

  const processText = async () => {
    if (!input) return;
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = mode === 'summarize' 
        ? `Summarize this text in 2 sentences:\n${input}`
        : `Fix grammar and make this text more professional:\n${input}`;

      // Use Flash Lite for speed
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-lite-latest',
        contents: prompt
      });
      
      setOutput(response.text || "No output");
    } catch (e) {
      setOutput("Error processing text.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-full bg-slate-900 p-6">
      <div className="max-w-2xl mx-auto space-y-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <Zap className="text-yellow-400" />
          Fast Lab
        </h2>
        <p className="text-slate-400">High-speed tasks using Gemini Flash Lite.</p>

        <div className="flex bg-slate-800 p-1 rounded-lg w-fit">
          <button
            onClick={() => setMode('summarize')}
            className={`px-4 py-2 rounded-md flex items-center gap-2 ${mode === 'summarize' ? 'bg-slate-600 text-white' : 'text-slate-400'}`}
          >
            <FileText size={16} /> Summarizer
          </button>
          <button
             onClick={() => setMode('grammar')}
             className={`px-4 py-2 rounded-md flex items-center gap-2 ${mode === 'grammar' ? 'bg-slate-600 text-white' : 'text-slate-400'}`}
          >
            <CheckCheck size={16} /> Proofreader
          </button>
        </div>

        <textarea 
          className="w-full h-40 bg-slate-800 border border-slate-700 rounded-lg p-4 text-white focus:ring-2 focus:ring-yellow-400 focus:outline-none"
          placeholder="Paste text here..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />

        <button
          onClick={processText}
          disabled={loading || !input}
          className="bg-yellow-500 hover:bg-yellow-600 disabled:opacity-50 text-slate-900 font-bold px-6 py-2 rounded-lg"
        >
          {loading ? 'Processing...' : 'Run Fast Action'}
        </button>

        {output && (
          <div className="bg-slate-800 border-l-4 border-yellow-400 p-4 rounded text-slate-200">
            {output}
          </div>
        )}
      </div>
    </div>
  );
};
