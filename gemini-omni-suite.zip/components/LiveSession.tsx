import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { Mic, MicOff, Volume2, Activity } from 'lucide-react';
import { decodeAudioData, createPcmBlob } from '../utils/audioUtils';

export const LiveSession: React.FC = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [status, setStatus] = useState<'disconnected' | 'connecting' | 'connected' | 'error'>('disconnected');
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sessionRef = useRef<any>(null); // To store session object
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  
  // Audio Playback Queue
  const nextStartTimeRef = useRef<number>(0);
  const scheduledSources = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Animation frame for visualizer
  const animRef = useRef<number>();

  const cleanup = () => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }
    if (sourceRef.current) {
      sourceRef.current.disconnect();
      sourceRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (inputContextRef.current) {
      inputContextRef.current.close();
      inputContextRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    if (animRef.current) {
      cancelAnimationFrame(animRef.current);
    }
    scheduledSources.current.forEach(s => s.stop());
    scheduledSources.current.clear();
    setIsConnected(false);
    setStatus('disconnected');
    setIsSpeaking(false);
  };

  const startSession = async () => {
    try {
      setStatus('connecting');
      
      // Initialize Audio Contexts
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      inputContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      
      nextStartTimeRef.current = audioContextRef.current.currentTime;

      // Get Mic Stream
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
          },
          systemInstruction: "You are a helpful, witty, and concise AI assistant.",
        },
        callbacks: {
          onopen: () => {
            console.log('Live session opened');
            setStatus('connected');
            setIsConnected(true);
            
            // Setup Input Processing
            if (!inputContextRef.current) return;
            
            const source = inputContextRef.current.createMediaStreamSource(stream);
            sourceRef.current = source;
            
            // Use ScriptProcessor as per guidelines (standard Web Audio API for raw PCM access)
            const processor = inputContextRef.current.createScriptProcessor(4096, 1, 1);
            processorRef.current = processor;
            
            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createPcmBlob(inputData);
              
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            
            source.connect(processor);
            processor.connect(inputContextRef.current.destination);
          },
          onmessage: async (msg: LiveServerMessage) => {
            const audioData = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audioData && audioContextRef.current) {
              setIsSpeaking(true);
              const ctx = audioContextRef.current;
              
              // Ensure gapless playback
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              
              const audioBuffer = await decodeAudioData(
                base64ToUint8Array(audioData), // Helper needed here
                ctx,
                24000,
                1
              );
              
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(ctx.destination);
              
              source.addEventListener('ended', () => {
                scheduledSources.current.delete(source);
                if (scheduledSources.current.size === 0) {
                   setIsSpeaking(false);
                }
              });
              
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              scheduledSources.current.add(source);
            }

            if (msg.serverContent?.turnComplete) {
               setIsSpeaking(false);
            }
          },
          onclose: () => {
            console.log('Live session closed');
            cleanup();
          },
          onerror: (err) => {
            console.error('Live session error', err);
            cleanup();
            setStatus('error');
          }
        }
      });
      
      sessionRef.current = sessionPromise;

    } catch (e) {
      console.error("Failed to start live session", e);
      cleanup();
      setStatus('error');
    }
  };

  // Helper for inline base64 to uint8 (local to this file or import)
  function base64ToUint8Array(base64: string): Uint8Array {
      const binaryString = atob(base64);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
          bytes[i] = binaryString.charCodeAt(i);
      }
      return bytes;
  }

  // Visualizer Effect
  useEffect(() => {
    if (!canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    let hue = 0;
    const draw = () => {
      if (!ctx || !canvasRef.current) return;
      ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
      
      const cx = canvasRef.current.width / 2;
      const cy = canvasRef.current.height / 2;
      
      if (isConnected) {
        hue += 1;
        ctx.strokeStyle = `hsl(${hue % 360}, 70%, 60%)`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        // Simple circle pulse simulation
        const r = 50 + (isSpeaking ? Math.random() * 20 : 0);
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.stroke();

        if (isSpeaking) {
          ctx.beginPath();
          ctx.arc(cx, cy, r + 10, 0, Math.PI * 2);
          ctx.strokeStyle = `hsl(${(hue + 180) % 360}, 50%, 50%)`;
          ctx.stroke();
        }
      } else {
        ctx.fillStyle = '#334155';
        ctx.beginPath();
        ctx.arc(cx, cy, 40, 0, Math.PI * 2);
        ctx.fill();
      }
      
      animRef.current = requestAnimationFrame(draw);
    };
    draw();
    return () => {
        if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [isConnected, isSpeaking]);

  return (
    <div className="flex flex-col h-full bg-slate-900 items-center justify-center p-6 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-indigo-900/20 via-slate-900 to-slate-900 pointer-events-none" />
      
      <div className="z-10 text-center space-y-8">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2 tracking-tight">Gemini Live</h2>
          <p className="text-slate-400">Real-time multimodal conversation</p>
        </div>

        <div className="relative">
          <canvas 
            ref={canvasRef} 
            width={300} 
            height={300} 
            className="rounded-full bg-slate-800/50 shadow-2xl backdrop-blur-sm"
          />
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            {isConnected ? (
              <Activity className={`w-12 h-12 ${isSpeaking ? 'text-indigo-400' : 'text-slate-500'} transition-colors`} />
            ) : (
              <MicOff className="w-12 h-12 text-slate-600" />
            )}
          </div>
        </div>

        <div className="flex justify-center gap-4">
          {!isConnected ? (
            <button
              onClick={startSession}
              disabled={status === 'connecting'}
              className="group relative inline-flex items-center justify-center px-8 py-3 text-lg font-medium text-white transition-all duration-200 bg-indigo-600 rounded-full hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {status === 'connecting' ? 'Connecting...' : 'Start Conversation'}
              <Mic className="ml-2 w-5 h-5 group-hover:scale-110 transition-transform" />
            </button>
          ) : (
            <button
              onClick={cleanup}
              className="inline-flex items-center justify-center px-8 py-3 text-lg font-medium text-white transition-all duration-200 bg-red-600 rounded-full hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
            >
              End Session
            </button>
          )}
        </div>
        
        {status === 'error' && (
          <p className="text-red-400 text-sm mt-4">Connection failed. Please check permissions and try again.</p>
        )}
      </div>
    </div>
  );
};
